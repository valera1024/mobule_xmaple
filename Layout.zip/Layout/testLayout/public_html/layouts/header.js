/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
// FILE: header.js
import { userProfile } from '../components/user-profile';

class Header {


  loadHeader() {

    // Invoke the method
    userProfile.loadUserProfile();

    console.log('Header component is loaded...');

  }

}

export let header = new Header(); 

