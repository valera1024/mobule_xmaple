/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

// FILE: users.js

class Users {

  loadUsers() {

    console.log('Users component is loaded...');

  }
}

export let users = new Users(); 
