/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

// FILE: user-profile.js

class UserProfile {

  loadUserProfile() {

   console.log('User-profile component is loaded...');

  }
}

export let userProfile = new UserProfile(); 
